<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'app_default_index', '_controller' => 'App\\Controller\\DefaultController::index'], null, null, null, false, false, null]],
        '/main' => [[['_route' => 'mainPage', '_controller' => 'App\\Controller\\DefaultController::main'], null, null, null, false, false, null]],
        '/search' => [[['_route' => 'search', '_controller' => 'App\\Controller\\DefaultController::search'], null, null, null, false, false, null]],
        '/addAuthor' => [[['_route' => 'addAuthor', '_controller' => 'App\\Controller\\DefaultController::addAuthor'], null, null, null, false, false, null]],
        '/removeAuthor' => [[['_route' => 'removeAuthor', '_controller' => 'App\\Controller\\DefaultController::removeAuthor'], null, null, null, false, false, null]],
        '/editAuthor' => [[['_route' => 'editAuthor', '_controller' => 'App\\Controller\\DefaultController::editAuthor'], null, null, null, false, false, null]],
        '/addBook' => [[['_route' => 'addBook', '_controller' => 'App\\Controller\\DefaultController::addBook'], null, null, null, false, false, null]],
        '/removeBook' => [[['_route' => 'removeBook', '_controller' => 'App\\Controller\\DefaultController::removeBook'], null, null, null, false, false, null]],
        '/editBook' => [[['_route' => 'editBook', '_controller' => 'App\\Controller\\DefaultController::editBook'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/edit(?'
                    .'|Author/([^/]++)(*:65)'
                    .'|Book/([^/]++)(*:85)'
                .')'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        65 => [[['_route' => 'editAuthor_Id', '_controller' => 'App\\Controller\\DefaultController::editAuthorId'], ['authorId'], null, null, false, true, null]],
        85 => [
            [['_route' => 'editBook_Id', '_controller' => 'App\\Controller\\DefaultController::editBookId'], ['bookId'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
