<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_927f40588e7cdf36f56433966eb9f0c63dc1131db45bf50a7dae3b5059183a05 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "
        ";
        // line 11
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </head>
    <body>
    <div class=\"navbar\">
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Все книги
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/main\">Все книги</a>
      <a href=\"/search\">Поиск...</a>
      <a href=\"/about\">О приложении</a>
    </div>
  </div>
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Книга
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/addBook\">Добавить книгу</a>
      <a href=\"/removeBook\">Удалить книгу</a>
      <a href=\"/editBook\">Редактировать книгу</a>
    </div>
  </div>
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Автор
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/addAuthor\">Добавить автора</a>
      <a href=\"/removeAuthor\">Удалить автора</a>
      <a href=\"/editAuthor\">Редактировать автора</a>
    </div>
  </div>
</div>
        ";
        // line 46
        $this->displayBlock('body', $context, $blocks);
        // line 47
        echo "    </body>
</html>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Bookshelf application";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "        <link href=\"/menu.css\" rel=\"stylesheet\">
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 46
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  149 => 46,  137 => 11,  129 => 8,  122 => 7,  109 => 6,  100 => 47,  98 => 46,  62 => 12,  60 => 11,  57 => 10,  55 => 7,  51 => 6,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
        <title>{% block title %}Bookshelf application{% endblock %}</title>
        {% block stylesheets %}
        <link href=\"/menu.css\" rel=\"stylesheet\">
        {% endblock %}

        {% block javascripts %}{% endblock %}
    </head>
    <body>
    <div class=\"navbar\">
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Все книги
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/main\">Все книги</a>
      <a href=\"/search\">Поиск...</a>
      <a href=\"/about\">О приложении</a>
    </div>
  </div>
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Книга
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/addBook\">Добавить книгу</a>
      <a href=\"/removeBook\">Удалить книгу</a>
      <a href=\"/editBook\">Редактировать книгу</a>
    </div>
  </div>
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Автор
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/addAuthor\">Добавить автора</a>
      <a href=\"/removeAuthor\">Удалить автора</a>
      <a href=\"/editAuthor\">Редактировать автора</a>
    </div>
  </div>
</div>
        {% block body %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\Openserver\\OpenServer\\domains\\symfony\\bookshelf\\templates\\base.html.twig");
    }
}
