<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* editBookFormChoose.html.twig */
class __TwigTemplate_94005d0b7c6f6acb724613342ff0ae3737166e77e01cec897bbc66c60ef37b1d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "editBookFormChoose.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "editBookFormChoose.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"formD\">
";
        // line 5
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["booklist"]) || array_key_exists("booklist", $context) ? $context["booklist"] : (function () { throw new RuntimeError('Variable "booklist" does not exist.', 5, $this->source); })()), 'form_start');
        echo "
";
        // line 6
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["booklist"]) || array_key_exists("booklist", $context) ? $context["booklist"] : (function () { throw new RuntimeError('Variable "booklist" does not exist.', 6, $this->source); })()), 'widget');
        echo "
";
        // line 7
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["booklist"]) || array_key_exists("booklist", $context) ? $context["booklist"] : (function () { throw new RuntimeError('Variable "booklist" does not exist.', 7, $this->source); })()), 'form_end');
        echo "    

";
        // line 10
        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 10, $this->source); })()), "request", [], "any", false, false, false, 10), "get", [0 => "status"], "method", false, false, false, 10) == "success")) {
            // line 11
            echo "    <p class =\"dbMessage\">Данные успешно изменены в базе данных</p>
";
        }
        // line 12
        echo "    
    </div>
    
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "editBookFormChoose.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 12,  77 => 11,  75 => 10,  70 => 7,  66 => 6,  62 => 5,  59 => 4,  52 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"formD\">
{{ form_start(booklist) }}
{{ form_widget(booklist) }}
{{ form_end(booklist) }}    

{#{{app.request.get('status')}} Это ГЕТ параметр, который показывает успешность действия добавления в базу#}
{% if app.request.get('status') == \"success\" %}
    <p class =\"dbMessage\">Данные успешно изменены в базе данных</p>
{% endif %}    
    </div>
    
{% endblock %}", "editBookFormChoose.html.twig", "C:\\Openserver\\OpenServer\\domains\\symfony\\bookshelf\\templates\\editBookFormChoose.html.twig");
    }
}
