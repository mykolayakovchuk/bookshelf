<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* main.html.twig */
class __TwigTemplate_27ed22695198a0a0aa83348c36b5498e7b0771cbe2018cfe1d79335d5460c3c8 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "main.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "main.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 3
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "

    <link href=\"/mainview.css\" rel=\"stylesheet\" />
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 7
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "<main>
";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["allBooks"]) || array_key_exists("allBooks", $context) ? $context["allBooks"] : (function () { throw new RuntimeError('Variable "allBooks" does not exist.', 9, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["book"]) {
            // line 10
            echo "<div class=\"column\">
    <div class=\"card\">
";
            // line 12
            if (twig_get_attribute($this->env, $this->source, $context["book"], "getImagelink", [], "any", false, false, false, 12)) {
                // line 13
                echo "      <img src=\"/uploads/bookcover/";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "getImagelink", [], "any", false, false, false, 13), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "getNamebook", [], "any", false, false, false, 13), "html", null, true);
                echo "\" class=\"bookcover\" >
";
            } else {
                // line 15
                echo "      <img src=\"/uploads/bookcover/undefined_bookcover.png\" alt=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "getNamebook", [], "any", false, false, false, 15), "html", null, true);
                echo "\" class=\"bookcover\" >
";
            }
            // line 17
            echo "      <div class=\"container\">
        <h2>";
            // line 18
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "getNamebook", [], "any", false, false, false, 18), "html", null, true);
            echo "</h2>
        <p class=\"title\">";
            // line 19
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "getAuthors", [], "any", false, false, false, 19), "html", null, true);
            echo "</p>
        <p>";
            // line 20
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "getComment", [], "any", false, false, false, 20), "html", null, true);
            echo "</p>
        <p>";
            // line 21
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "getYear", [], "any", false, false, false, 21), "html", null, true);
            echo "</p>
        <p><button class=\"button\">Подробнее...</button></p>
      </div>
    </div>
  </div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "</main>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "main.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 27,  121 => 21,  117 => 20,  113 => 19,  109 => 18,  106 => 17,  100 => 15,  92 => 13,  90 => 12,  86 => 10,  82 => 9,  79 => 8,  72 => 7,  60 => 3,  53 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block stylesheets %}
    {{ parent() }}

    <link href=\"/mainview.css\" rel=\"stylesheet\" />
{% endblock %}
{% block body %}
<main>
{% for book in allBooks %}
<div class=\"column\">
    <div class=\"card\">
{% if book.getImagelink %}
      <img src=\"/uploads/bookcover/{{book.getImagelink}}\" alt=\"{{ book.getNamebook }}\" class=\"bookcover\" >
{% else %}
      <img src=\"/uploads/bookcover/undefined_bookcover.png\" alt=\"{{ book.getNamebook }}\" class=\"bookcover\" >
{% endif %}
      <div class=\"container\">
        <h2>{{ book.getNamebook }}</h2>
        <p class=\"title\">{{ book.getAuthors }}</p>
        <p>{{ book.getComment }}</p>
        <p>{{ book.getYear }}</p>
        <p><button class=\"button\">Подробнее...</button></p>
      </div>
    </div>
  </div>
{% endfor %}
</main>
{% endblock %}

", "main.html.twig", "C:\\Openserver\\OpenServer\\domains\\symfony\\bookshelf\\templates\\main.html.twig");
    }
}
