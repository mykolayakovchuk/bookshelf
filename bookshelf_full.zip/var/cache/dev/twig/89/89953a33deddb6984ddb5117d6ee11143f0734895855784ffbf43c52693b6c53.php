<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* editBookForm.html.twig */
class __TwigTemplate_5e09edc5cf50a6d77b99f336684c29e212132f976579d1e72782eaf8b2f31363 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "editBookForm.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "editBookForm.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"formD\">
";
        // line 5
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 5, $this->source); })()), 'form_start');
        echo "
";
        // line 6
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 6, $this->source); })()), 'widget');
        echo "
";
        // line 7
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 7, $this->source); })()), 'form_end');
        echo "
    </div>
<div class=\"bookcoverPreview\">
";
        // line 10
        if (twig_get_attribute($this->env, $this->source, (isset($context["bookExemplar"]) || array_key_exists("bookExemplar", $context) ? $context["bookExemplar"] : (function () { throw new RuntimeError('Variable "bookExemplar" does not exist.', 10, $this->source); })()), "getImagelink", [], "any", false, false, false, 10)) {
            // line 11
            echo "    Обложка для данной книги:<br>
<img src=\"/uploads/bookcover/";
            // line 12
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["bookExemplar"]) || array_key_exists("bookExemplar", $context) ? $context["bookExemplar"] : (function () { throw new RuntimeError('Variable "bookExemplar" does not exist.', 12, $this->source); })()), "getImagelink", [], "any", false, false, false, 12), "html", null, true);
            echo "\" />
";
        } else {
            // line 14
            echo "    Для данной книги обложка не загружена.
";
        }
        // line 15
        echo " 
</div>    
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "editBookForm.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  86 => 14,  81 => 12,  78 => 11,  76 => 10,  70 => 7,  66 => 6,  62 => 5,  59 => 4,  52 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"formD\">
{{ form_start(form) }}
{{ form_widget(form) }}
{{ form_end(form) }}
    </div>
<div class=\"bookcoverPreview\">
{% if bookExemplar.getImagelink %}
    Обложка для данной книги:<br>
<img src=\"/uploads/bookcover/{{bookExemplar.getImagelink}}\" />
{% else %}
    Для данной книги обложка не загружена.
{% endif %} 
</div>    
{% endblock %}", "editBookForm.html.twig", "C:\\Openserver\\OpenServer\\domains\\symfony\\bookshelf\\templates\\editBookForm.html.twig");
    }
}
