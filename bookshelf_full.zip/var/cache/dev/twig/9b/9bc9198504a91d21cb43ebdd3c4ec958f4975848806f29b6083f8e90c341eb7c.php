<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_5b01dba11bf1bee6f5b10a76913ae15afb2bf3da5a332d77f6ecb2d17a07021e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <link href=\"menu.css\" rel=\"stylesheet\">
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "
        ";
        // line 9
        $this->displayBlock('javascripts', $context, $blocks);
        // line 10
        echo "    </head>
    <body>
    <div class=\"navbar\">
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Все книги
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/allBook\">Все книги</a>
      <a href=\"/allBook\">Все книги</a>
      <a href=\"/allBook\">Все книги</a>
    </div>
  </div>
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Книга
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/addBook\">Добавить книгу</a>
      <a href=\"/removeBook\">Удалить книгу</a>
      <a href=\"/editBook\">Редактировать книгу</a>
    </div>
  </div>
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Автор
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/addAuthor\">Добавить автора</a>
      <a href=\"/removeAuthor\">Удалить автора</a>
      <a href=\"/editAuthor\">Редактировать автора</a>
    </div>
  </div>
</div>
        ";
        // line 44
        $this->displayBlock('body', $context, $blocks);
        // line 45
        echo "    </body>
</html>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Bookshelf application";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 9
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 44
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  146 => 44,  134 => 9,  122 => 7,  109 => 6,  100 => 45,  98 => 44,  62 => 10,  60 => 9,  57 => 8,  55 => 7,  51 => 6,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <link href=\"menu.css\" rel=\"stylesheet\">
        <title>{% block title %}Bookshelf application{% endblock %}</title>
        {% block stylesheets %}{% endblock %}

        {% block javascripts %}{% endblock %}
    </head>
    <body>
    <div class=\"navbar\">
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Все книги
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/allBook\">Все книги</a>
      <a href=\"/allBook\">Все книги</a>
      <a href=\"/allBook\">Все книги</a>
    </div>
  </div>
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Книга
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/addBook\">Добавить книгу</a>
      <a href=\"/removeBook\">Удалить книгу</a>
      <a href=\"/editBook\">Редактировать книгу</a>
    </div>
  </div>
  <div class=\"dropdown\">
    <button class=\"dropbtn\">Автор
      <i class=\"fa fa-caret-down\"></i>
    </button>
    <div class=\"dropdown-content\">
      <a href=\"/addAuthor\">Добавить автора</a>
      <a href=\"/removeAuthor\">Удалить автора</a>
      <a href=\"/editAuthor\">Редактировать автора</a>
    </div>
  </div>
</div>
        {% block body %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\Openserver\\OpenServer\\domains\\symfony\\bookshelf\\templates\\base.html.twig");
    }
}
